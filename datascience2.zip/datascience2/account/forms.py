from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django import forms
from django.contrib.auth.models import User
from captcha.fields import CaptchaField


class CreateUserForm(UserCreationForm):
	username = forms.CharField(
        label="帳號",
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
	email = forms.EmailField(
		label="電子郵件",
		widget=forms.EmailInput(attrs={'class': 'form-control'})
	)
	password1 = forms.CharField(
	    label="密碼",
	    widget=forms.PasswordInput(attrs={'class': 'form-control'})
	)
	password2 = forms.CharField(
	    label="密碼確認",
	    widget=forms.PasswordInput(attrs={'class': 'form-control'})
	)
	captcha=CaptchaField()
	class Meta:
		model = User
		fields = ['username', 'email', 'password1', 'password2']
	def __init__(self, *args, **kwargs):
		super(CreateUserForm, self).__init__(*args, **kwargs)
		self.fields['captcha'].label = '不是機器人'

class RegistrationForm(forms.Form):
	username = forms.CharField(
		label = '帳號',
		widget = forms.TextInput(attrs={'class': 'form-control'})
	)
	password = forms.CharField(
		label = '密碼',
		widget = forms.PasswordInput(attrs={'class': 'form-control'})
	)

# from django import forms
# from django.contrib.auth.forms import UserCreationForm
# from django.contrib.auth import authenticate
# from account.models import Account

# class RegistrationForm(UserCreationForm):
# 	email = forms.EmailField(max_length=200, help_text="必填，請輸入可使用之信箱。")

# 	class Meta:
# 		model = Account
# 		fields = ('email', 'username', 'password')


# 	def cleans_email(self):
# 		email = self.cleaned_data['email'].lower()
# 		try:
# 			account = Account.objects.get(email=email)
# 		except Exception as e:
# 			return email
# 		raise forms.ValidationError(f"信箱 {email} 已註冊過。")

# 	def cleans_username(self):
# 		username = self.cleaned_data['username']
# 		try:
# 			account = Account.objects.get(username=username)
# 		except Exception as e:
# 			return username
# 		raise forms.ValidationError(f"名稱 {username} 已註冊過。")