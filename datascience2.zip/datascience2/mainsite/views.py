from django.http import HttpResponse
from datetime import datetime
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .scrapy import House
import time
# Create your views here.


def tv(request,tvno = 0):
	tv_list = [{'name':'35線上賞屋','tvcode':'7MTi5q9fVIM'},
				{'name':'風傳媒','tvcode':'UUHVno5_oK4'},
				{'name':'好房網','tvcode':'TepDZndZw98'},]
	now = datetime.now()
	tvno = tvno
	tv = tv_list[tvno]
	return render(request,'boardbase.html',locals())





@login_required(login_url='register')
def index(request):
	#now = datetime.now()
#if 'sid' in request.POST:
	city = request.POST.get('city')
	district = request.POST.get('district')
	year = request.POST.get('year')
	lat = request.POST.get('lat')
	lon  = request.POST.get('lon')
	bs = request.POST.get('bs')
	g = request.POST.get('g')
	l  = request.POST.get('l')
	room = request.POST.get('room')
	living = request.POST.get('living')
	toilet = request.POST.get('toilet')
	s = request.POST.get('s')
	real_s = request.POST.get('real_s')


	house = House(city, district,year,lat,lon,bs,g,l,room,living,toilet,s,real_s)

	context={"infos":house.scrape()}
	return render(request, "index.html", context)

